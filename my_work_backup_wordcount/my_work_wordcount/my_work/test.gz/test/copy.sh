#!/bin/sh
#cp test_wordcount /home/kuangren/mpirundir/
scp test_wordcount 192.168.5.241:/home/kuangren/bishe/project/my_work/test
scp test_data1.txt 192.168.5.241:/home/kuangren/bishe/project/my_work/test
scp test_data2.txt 192.168.5.241:/home/kuangren/bishe/project/my_work/test
#scp test_wordcount 192.168.5.241:/home/kuangren/mpirundir/
