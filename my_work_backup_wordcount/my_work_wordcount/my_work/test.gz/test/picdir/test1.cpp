kuangren.cpp
