#!/bin/sh
scp word_10MB.txt 192.168.5.199:/home/kuangren/bishe/project/my_work/test
